#include <bits/stdc++.h>
#include "../include/generalised_tic_tac_toe.h"

using namespace std;

#define inf 10000
#define neginf -10000

/* Takes input of a game board and returns proved or disproved as applicable for the position assuming it is player's turn*/

// return maximum of a and b
int max(int a , int b){
    if(a >= b)
        return a;

    else
        return b;
}

int min(int a , int b){
    if(a <= b)
        return a;

    else
        return b;
}

class pn_node{

    // Todo replace board with a hash value and make a hash map

    char** board; // status of the board
    vector<pn_node*> children; // an array of pointers to the children
    bool type; // true for OR node and false for AND node
    char value; 
    bool isInternal; // true for internal node and false otherwise
    void generate_children(); // generates children of the node
    
    public:

        int proof_number , disproof_number;
        pn_node* parent;
        
        pn_node(char** board_status){
            board = new char*[N];

            for(int i = 0 ; i < N ; i++)
                board[i] = new char[N];

            for(int i = 0 ; i < N ; i++){
                for(int j = 0 ; j < N ; j++)
                    board[i][j] = board_status[i][j];
            }

        }

        void set_parent(pn_node* par){
            parent = par;
            if(par == NULL)
                type = true;
            else 
                type = !(par->type);
            isInternal = false;
        }

        ~pn_node(){
            for(int i = 0 ; i < N ; i++)
                delete [] board[i];

            delete [] board;
        }

        void evaluate_node(); // sets value to '0' if disproven , '1' if proven and '2' if unknown
        void setProofandDisproofNumbers(); // sets the proof and disproof numbers as per the algorithm
        pn_node* selectMostProvingNode(); // selects the most proving node as per the specs
        void ExpandNode(); // expand the leaf node , forming children and assigning their proof and disproof numbers
        void print_data(){
            cout<<"\n";
            print_board(board);
            cout<<"\n";
        }

};

void pn_node::generate_children(){
    char foo;

    if(type)
        foo = player;
    else
        foo = opponent;

    for(int i = 0 ; i < N ; i++){
        for(int j = 0 ; j < N ; j++){
            if(board[i][j] == '_'){
                // make move
                board[i][j] = foo;

                pn_node* child = new pn_node(board);
                
                //undo the move
                board[i][j] = '_';

                child->set_parent(this);
                children.push_back(child);
            }
        }
    }
}

void pn_node::evaluate_node(){
    int score = evaluate(board);

    if(score == 10)
        value = '1';

    else if(score == -10)
        value = '0';

    else
        value = '2';
}

void pn_node::setProofandDisproofNumbers(){
    if(isInternal){
        if(type){ // OR node
            proof_number = inf; disproof_number = 0;

            for(int i = 0 ; i < children.size() ; i++){
                disproof_number+=(children[i]->disproof_number);
                proof_number = min(proof_number , children[i]->proof_number);
            }

            if(disproof_number >= inf)
                disproof_number = inf;
        }

        else{ // AND node
            disproof_number = inf; proof_number = 0;

            for(int i = 0 ; i < children.size() ; i++){
                proof_number+=(children[i]->proof_number);
                disproof_number = min(disproof_number , children[i]->disproof_number);
            }

            if(proof_number >= inf)
                proof_number = inf;

        }
    }

    else{
        switch(value){
            case '0': // disproven
                proof_number = inf;
                disproof_number = 0;
                break;

            case '1': //proven
                proof_number = 0;
                disproof_number = inf;
                break;

            case '2': //unknown
                proof_number = 1;
                disproof_number = 1;
                break;
        }
    }

}

pn_node* pn_node::selectMostProvingNode(){
    pn_node* n = this;

    while(n->isInternal){
        int value = inf;
        pn_node* best;

        if(n->type){ // OR node
            for(int i = 0 ; i < children.size() ; i++){
                if(value > children[i]->proof_number){ // select one with the minimum proof number
                    best = children[i];
                    value = children[i]->proof_number;
                }
            
            }
        }

        else{ // AND node
            for(int i = 0 ; i < children.size() ; i++){
                if(value > children[i]->disproof_number){ // select one with the minimum disproof number
                    best = children[i];
                    value = children[i]->disproof_number;
                }
            
            }
        }

        n = best;
    }

    return n;
}

void pn_node::ExpandNode(){
    generate_children();

    for(int i = 0 ; i < children.size() ; i++){
        children[i]->evaluate_node();
        children[i]->setProofandDisproofNumbers();

        if(type){ // OR node
            if(children[i]->proof_number == 0)
                break;
        }

        else{
            if(children[i]->disproof_number == 0)
                break;
        }

    }

    isInternal = true;
}

pn_node* update_ancestors(pn_node* n , pn_node* root){
    while(n != root){
        int old_proof = n->proof_number;
        int old_disproof = n->disproof_number;
        n->setProofandDisproofNumbers();

        if(n->proof_number == old_proof && n->disproof_number == old_disproof)
            return n; // if unchanged , then return

        n = n->parent;
    }

    root->setProofandDisproofNumbers();
    return root;
}

void pn_search(pn_node* root){
    root->evaluate_node();
    root->setProofandDisproofNumbers();
    pn_node* current = root;

    while(root->proof_number != 0 && root->disproof_number != 0){
        pn_node* most_proving = current->selectMostProvingNode();
        most_proving->ExpandNode();
        //most_proving->print_data();
        current = update_ancestors(most_proving , root);
        //cout<<root->proof_number<<root->disproof_number;
    }

    if(root->proof_number == 0)
        cout<<"Proved\n";
    else
        cout<<"Disproved\n";

    //delete current;
}

int main(){

    char** board = new char*[N];

    for(int i = 0 ; i < N ; i++)
        board[i] = new char[N];

    /*cout<<"Enter the game board\n";

    for(int i = 0 ; i < N ; i++){
        for(int j = 0 ; j < N ; j++){
            cin>>board[i][j];
        }
    }*/

    board[0][0] = 'o'; board[0][1] = '_'; board[0][2] = 'o'; board[0][3] = '_';
    board[1][0] = 'x'; board[1][1] = 'x'; board[1][2] = 'x'; board[1][3] = '_';
    board[2][0] = '_'; board[2][1] = '_'; board[2][2] = '_'; board[2][3] = '_';
    board[3][0] = 'o'; board[3][1] = '_'; board[3][2] = '_'; board[3][3] = '_';

    pn_node* root = new pn_node(board);
    root->set_parent(NULL);
    pn_search(root);

    for(int i = 0 ; i < N ; i++)
        delete [] board[i];

    delete [] board;
    delete root;

    return 0;
}