#include <bits/stdc++.h>
#include "../include/generalised_tic_tac_toe.h" // can be changed for different games(board games)

using namespace std;

#define inf 1000
#define neginf -1000

struct Move{
    int row , col;
};

// return maximum of a and b
int max(int a , int b){
    if(a >= b)
        return a;

    else
        return b;
}

int min(int a , int b){
    if(a <= b)
        return a;

    else
        return b;
}

// returns the value of the board after considering all possibilities
int minimax(char** board, int depth, bool isMax){ 
    int score = evaluate(board); 
  
    // Maximizer has won 
    if (score == 10) 
        return score; 
  
    // Minimizer has won
    if (score == -10) 
        return score; 
  
    // If there are no more moves and no winner then 
    // it is a tie 
    if (isMovesLeft(board)==false) 
        return 0; 
  
    // If this maximizer's move 
    if(isMax){ 
        int best = neginf;
  
        for (int i = 0; i < N; i++){ 
            for (int j = 0; j < N; j++){ 
                // Check if cell is empty 
                if (board[i][j]=='_'){ 
                    // Make the move 
                    board[i][j] = player; 
  
                    // Call minimax recursively 
                    best = max(best, minimax(board, depth+1, !isMax)); 
  
                    // Undo the move 
                    board[i][j] = '_'; 
                } 
            } 
        } 
        return best; 
    } 
  
    // If this minimizer's move 
    else{ 
        int best = inf;
  
        for (int i = 0; i < N; i++){ 
            for (int j = 0; j < N; j++){ 
                // Check if move is legal 
                if (board[i][j] == '_'){

                    // Make the move 
                    board[i][j] = opponent; 
  
                    best = min(best, minimax(board, depth+1, !isMax)); 
  
                    // Undo the move 
                    board[i][j] = '_'; 
                } 
            } 
        } 
        return best; 
    } 
}

// returns the best move for the player
Move findBestMove(char** board){
    int bestVal = -1000; 
    Move bestMove; 
    bestMove.row = -1; 
    bestMove.col = -1; 
  
    /*Traverse all cells, evaluate minimax function for 
      all empty cells. And return the cell with optimal 
      value.*/ 
    for (int i = 0; i < N; i++) 
    { 
        for (int j = 0; j < N; j++) 
        { 
            // Check if cell is empty 
            if (board[i][j]=='_') 
            { 
                // Make the move 
                board[i][j] = player; 
  
                // compute evaluation function for this 
                // move. 
                int moveVal = minimax(board, 0, false); 
  
                // Undo the move 
                board[i][j] = '_'; 
  
                // If the value of the current move is 
                // more than the best value, then update 
                // best 
                if (moveVal > bestVal) 
                { 
                    bestMove.row = i; 
                    bestMove.col = j; 
                    bestVal = moveVal; 
                } 
            } 
        } 
    } 
  
    return bestMove; 
} 

int main(){
    char** board = new char*[N];

    for(int i = 0 ; i < N ; i++)
        board[i] = new char[N];

    cout<<"Enter the game board\n";

    for(int i = 0 ; i < N ; i++){
        for(int j = 0 ; j < N ; j++){
            cin>>board[i][j];
        }
    }

    Move bestMove = findBestMove(board);

    cout<<"The optimal move is:\n";
    cout<<"Row: "<<bestMove.row<<endl;
    cout<<"Col: "<<bestMove.col<<endl;

    for(int i = 0 ; i < N ; i++)
        delete [] board[i];

    delete [] board;

    return 0;
}

