#include <bits/stdc++.h>

using namespace std;

/* The generalised tic tac toe is implemented on a 4x4 2-d character array with X,O or _ . X is the first player . 
   The desired polyamino is Tippy:
            |X|X|
              |X|X| 
    Sizes and polaminos can be updated , just update the evaluate function . 
    Currently , evaluate function : gives +10 if player 1 wins and -10 in case of draw or player 1 lose . */

#define N 4
#define player 'x'
#define opponent 'o'

//returns true if legal moves are left and false otherwise(completely filled board)
bool isMovesLeft(char** board){
    for(int i = 0 ; i < N ; i++){
        for(int j = 0 ; j < N ; j++){
            if(board[i][j] == '_')
                return true;
        }
    }

    return false;
}

//initialise a board as NxN with all units '_'
void initialise_board(char** board){
    for(int i = 0 ; i < N ; i++){
        for(int j = 0 ; j < N ; j++){
            board[i][j] = '_';
        }
    }
}

//returns true for a terminal position(player 1 win / player 1 lose / draw)
bool isTerminal(char** board){

    int i , j;

    for(i = 0 ; i < N ; i++){
        for(j = 0 ; j < (N-1) ; j++){
            if(board[i][j] == board[i][j+1] && board[i][j] != '_'){ // two in a row position like |X||X|
                if(j < (N-2) && i < (N-1) && board[i+1][j+1] == board[i+1][j+2] && board[i+1][j+1] == board[i][j]){ /* Represents a position like
                                                                                                                        |X||X|
                                                                                                                           |X||X| */
                    return true;

                }

                else if(j > 0 && i < (N-1) && board[i+1][j-1] == board[i+1][j] && board[i+1][j] == board[i][j]){ /* Represents a position like
                                                                                                                        |X||X|
                                                                                                                     |X||X| */
                    return true;

                }

                else if(i > 0 && i < (N-1) && board[i-1][j] == board[i][j] && board[i+1][j+1] == board[i][j]){ /* Represents a position like
                                                                                                                    |X|
                                                                                                                    |X||X|
                                                                                                                       |X| */
                    return true;

                }

                else if(i > 0 && i < (N-1) && board[i-1][j+1] == board[i][j] && board[i+1][j] == board[i][j]){  /* Represents a position like
                                                                                                                        |X|
                                                                                                                     |X||X|
                                                                                                                     |X| */
                    return true;

                }

            } 
        }
    }

    if(!isMovesLeft(board))
        return true;

    return false;
}


// return +10 for player 1 win , -10 for loss and 0 for draw
int evaluate(char** board){
    int i , j;

    for(i = 0 ; i < N ; i++){
        for(j = 0 ; j < (N-1) ; j++){
            if(board[i][j] == board[i][j+1] && board[i][j] != '_'){ // two in a row position like |X||X|
                if(j < (N-2) && i < (N-1) && board[i+1][j+1] == board[i+1][j+2] && board[i+1][j+1] == board[i][j]){ /* Represents a position like
                                                                                                                        |X||X|
                                                                                                                           |X||X| */
                    if(board[i][j] == player)
                        return 10;
                    else
                        return -10;

                }

                else if(j > 0 && i < (N-1) && board[i+1][j-1] == board[i+1][j] && board[i+1][j] == board[i][j]){ /* Represents a position like
                                                                                                                        |X||X|
                                                                                                                     |X||X| */
                    if(board[i][j] == player)
                        return 10;
                    else
                        return -10;

                }

                else if(i > 0 && i < (N-1) && board[i-1][j] == board[i][j] && board[i+1][j+1] == board[i][j]){ /* Represents a position like
                                                                                                                    |X|
                                                                                                                    |X||X|
                                                                                                                       |X| */
                    if(board[i][j] == player)
                        return 10;
                    else
                        return -10;

                }

                else if(i > 0 && i < (N-1) && board[i-1][j+1] == board[i][j] && board[i+1][j] == board[i][j]){  /* Represents a position like
                                                                                                                        |X|
                                                                                                                     |X||X|
                                                                                                                     |X| */
                    if(board[i][j] == player)
                        return 10;
                    else
                        return -10;

                }

            } 
        }
    }

    return 0;
}
