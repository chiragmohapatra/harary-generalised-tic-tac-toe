#ifndef GENERALISED_TIC_TAC_TOE_H

#define GENERALISED_TIC_TAC_TOE_H

#define N 4
#define player 'x'
#define opponent 'o'

bool isMovesLeft(char**);
int evaluate(char**);
bool isTerminal(char**);
void initialise_board(char**);
void print_board(char**);

#endif