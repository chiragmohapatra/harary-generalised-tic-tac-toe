#include <bits/stdc++.h>
#include "../include/generalised_tic_tac_toe.h" // can be changed for different games(board games)

using namespace std;

#define inf 10000
#define neginf -10000

struct Move{ // a move is charactersied by the row and the column
    int row , col;
};

// return maximum of a and b
int max(int a , int b){
    if(a >= b)
        return a;

    else
        return b;
}

int min(int a , int b){
    if(a <= b)
        return a;

    else
        return b;
}

// returns the value of the board after considering all possibilities
int minimax(char** board, int depth, bool isMax , int alpha , int beta){ 
    int score = evaluate(board); 
  
    // Maximizer has won 
    if (score == 10) 
        return (score-depth); // to make sure that the optimal move takes least possible steps to win
  
    // Minimizer has won
    if (score == -10) 
        return (score+depth); 
  
    // If there are no more moves and no winner then 
    // it is a tie 
    if (isMovesLeft(board)==false) 
        return 0; 
  
    // If this maximizer's move 
    if(isMax){ 
        int best = neginf;
  
        for (int i = 0; i < N; i++){ 
            for (int j = 0; j < N; j++){ 
                // Check if cell is empty 
                if (board[i][j]=='_'){ 
                    // Make the move 
                    board[i][j] = player; 

                    int val = minimax(board, depth+1, !isMax , alpha , beta);
  
                    best = max(best, val);
                    alpha = max(alpha , best);

                    // Undo the move 
                    board[i][j] = '_'; 

                    //alpha beta pruning
                    if(beta <= alpha) 
                        break;
  
                } 
            } 
        } 
        return best; 
    } 
  
    // If this minimizer's move 
    else{ 
        int best = inf;
  
        for (int i = 0; i < N; i++){ 
            for (int j = 0; j < N; j++){ 
                // Check if move is legal 
                if (board[i][j] == '_'){

                    // Make the move 
                    board[i][j] = opponent; 
  
                    int val = minimax(board, depth+1, !isMax , alpha , beta);
  
                    best = min(best, val);
                    beta = min(beta , best); 

                    // Undo the move 
                    board[i][j] = '_'; 

                    //alpha beta pruning
                    if(beta <= alpha) 
                        break;
                    
                } 
            } 
        } 
        return best; 
    } 
}

// returns the best move for the player
Move findBestMove(char** board){
    int bestVal = -1000; 
    Move bestMove; 
    bestMove.row = -1; 
    bestMove.col = -1; 
  
    /*Traverse all cells, evaluate minimax function for 
      all empty cells. And return the cell with optimal 
      value.*/ 
    for (int i = 0; i < N; i++) 
    { 
        for (int j = 0; j < N; j++) 
        { 
            // Check if cell is empty 
            if (board[i][j]=='_') 
            { 
                // Make the move 
                board[i][j] = player; 
  
                // compute evaluation function for this 
                // move. 
                int moveVal = minimax(board, 0, false , neginf , inf); //iniialise alpha as -inf and beta as +inf
  
                // Undo the move 
                board[i][j] = '_'; 
  
                // If the value of the current move is 
                // more than the best value, then update 
                // best 
                if (moveVal > bestVal) 
                { 
                    bestMove.row = i; 
                    bestMove.col = j; 
                    bestVal = moveVal; 
                } 
            } 
        } 
    } 
  
    return bestMove; 
} 

int main(){
    char** board = new char*[N];

    for(int i = 0 ; i < N ; i++)
        board[i] = new char[N];

    /*cout<<"Enter the game board\n";

    for(int i = 0 ; i < N ; i++){
        for(int j = 0 ; j < N ; j++){
            cin>>board[i][j];
        }
    }*/

    int r , c;

    board[0][0] = 'o'; board[0][1] = '_'; board[0][2] = 'o'; board[0][3] = '_';
    board[1][0] = '_'; board[1][1] = 'x'; board[1][2] = 'x'; board[1][3] = '_';
    board[2][0] = '_'; board[2][1] = '_'; board[2][2] = '_'; board[2][3] = '_';
    board[3][0] = '_'; board[3][1] = '_'; board[3][2] = '_'; board[3][3] = '_';

    print_board(board);
    cout<<"\n";

    while(!isTerminal(board)){
        Move bestMove = findBestMove(board);

        board[bestMove.row][bestMove.col] = 'x';

        cout<<"\n";

        print_board(board);

        if(isTerminal(board)){
            cout<<"Computer wins\n";
            break;
        }

        cout<<"\nEnter human move\n";
        cin>>r>>c;

        board[r][c] = 'o';

        print_board(board);

        if(isTerminal(board)){
            cout<<"Human wins\n";
            break;
        }
    }
    

    /*cout<<"The optimal move is:\n";
    cout<<"Row: "<<bestMove.row<<endl;
    cout<<"Col: "<<bestMove.col<<endl;*/

    

    for(int i = 0 ; i < N ; i++)
        delete [] board[i];

    delete [] board;

    return 0;
}

